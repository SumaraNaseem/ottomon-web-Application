// import Link from "next/link";

const page = () => {
  return (
    <div>
      shopping carts
    </div>
  )
}

export default page
